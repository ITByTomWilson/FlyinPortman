<?php
$config_host = 'localhost';
$config_user = 'flyinpor_userDB';
$config_password = 'P@$$w0rd!!';
$config_db = 'flyinpor_users';
?>
